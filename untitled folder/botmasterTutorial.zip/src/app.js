var express = require('express'); //added
const port = process.env.PORT || 8081; //added
var app = express(); //added
const Botmaster = require('botmaster');
const SocketioBot = require('botmaster-socket.io');
var http = require('http').Server(app);
var io = require('socket.io')(http);
var socket = io
var path = require('path');
// Routing for index.html
//app.use(express.static(__dirname + 'public')); //added
app.use(express.static('public'))


const botmaster = new Botmaster();

const socketioSettings = {
  id: 'BotTim',
  server:botmaster.server,
};

app.get('/input',function(req,res){
    console.log(req);
   res.send(socketioSettings.id);
});

socketioBot = new SocketioBot(socketioSettings);
botmaster.addBot(socketioBot);

botmaster.use({
  type:'incoming',
  name:'my-middleware',
  controller:(bot,update) => {
    return bot.reply(update,'Hello World');
  }
});

botmaster.on('error', (bot, err) => { // added
  console.log(err.stack); // added
}); //

emitter.setMaxListeners(5)

io.on('connection',function(){
    //console.log('a user connected');
    socket.on('chat message',function(msg){
      io.emit('chat message',msg);
    });
});

// const server = app.listen(port, '0.0.0.0', () => {  //added
//     console.log('Server listening at port %d', port);
// });

http.listen(port, function(){
  console.log('listening on *:' + port);
});
