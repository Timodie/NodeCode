import pandas as pd
import numpy as np
import xgboost as xgb
from sys import argv, stdout, path
import pickle
class RoutingClassifier:
    def __init__(self):
        # Try to load the model, if that doesn't work then build a new model
        try:
            # Open the pickle file, from the directory this script resides in
            self.model = pickle.load(open(path[0] + '/xgmodel.pickle.dat', "rb"))
        except:
            self.build_model()

    def build_model(self, save_model = True):
        # Open the incidents file, from the directory this script resides in
        store = pd.HDFStore(path[0] + '/incidents.h5')  # load the cleaned data
        unused_cols = ['UH_ORG_DIVISION', 'TITLE']  # Do not consider listed cols in features
        df_july = store['df_july']
        df_june = store['df_june']
        df_may = store['df_may']
        df_july_early, df_july_late = np.array_split(df_july, 2)
        con = pd.concat([df_june, df_may, df_july_early])

        X = np.array(con.drop(unused_cols + ['ASSIGNMENT'], 1))  # Create array of features by dropping the col we predict
        y = np.array(con['ASSIGNMENT'])  # Create an vector of the feature we want to predict

        param = {'silent': 1, 'objective': 'binary:logistic', 'max_depth': 6, 'booster': 'gbtree', 'min_child_weight': 7
            , 'reg_alpha': 1.6, 'reg_lambda': 1.6, 'eta': .1, 'gamma': .4, 'subsample': .75, 'colsample_bytree': .75}
        num_round = 20
        xg_train = xgb.DMatrix(X, label=y)

        bst = xgb.train(param, xg_train, num_round)

        self.model = bst
        if save_model:
            self.save_model()

    def save_model(self):
        # Save the pickle file, from the directory this script resides in
        pickle.dump(self.model, open(path[0] + '/xgmodel.pickle.dat', "wb"))

    def predict(self, param_set):
        return self.model.predict(param_set)

def main():
    caller = [int(i) for i in argv[1:]] # get the command line args as a list of strings, and cast them as ints
    r = RoutingClassifier()  # declare the classifier
    pred = r.predict(xgb.DMatrix(caller))  # predict where to route, returns an array of length 1 with the probability
    if round(pred[0]) == 1.0:  # if the probability is > .5
        route = 'Desk'
    else:
        route = 'Else'
        pred[0] = 1 - pred[0]  # convert the probability to respect the category returned
    return_string = route+'#'+str(pred[0]) # return the classification and the probability that it is in the category returned
    print(return_string)

if __name__ == '__main__':
    main()
