var express = require('express')
  , app = express()
  , home = require('jade').compileFile(__dirname + '/source/templates/home.jade')
  , chat = require('jade').compileFile(__dirname + '/source/templates/chat.jade')
  , uuidv1 = require('uuid/v1')
  , bodyParser = require('body-parser')
  , elasticsearch = require('elasticsearch')
  , MongoClient = require('mongodb').MongoClient
  , jsonObject = require(__dirname + '/source/resources/flat_exported_labels.json')
  , randomSentence = require('random-sentence')
  , PythonShell = require('python-shell');

app.use(express.static(__dirname + '/static'))

app.use('/bulma', express.static(__dirname + '/node_modules/bulma/'));
app.use('/fontawesome', express.static(__dirname + '/node_modules/font-awesome/'));

var client = new elasticsearch.Client( {
  host: 'apsrd9017:9200'
});

var mongoUrl = "mongodb://localhost:27017/mydb";

function mongoInsert(obj) {
  return MongoClient.connect(mongoUrl, function(err, db) {
    if (err) throw err;
    db.collection("chatlogs").insertOne(obj, function(err, res) {
      if (err) throw err;
      console.log("chatlog inserted");
      db.close();
    });
  });
}

function mongoSearch(keyword) {
  return MongoClient.connect('mongodb://localhost:27017/mydb').then(function(db) {
    var collection = db.collection('chatlogs');
    var query = { chat_id: keyword };
    return collection.find(query).toArray();
  }).then(function(items) {
    console.log(items);
    return items;
  });
}

app.get('/', function (req, res, next) {
  try {
    var html = home({pageData: {chat_id : uuidv1()}})
    res.send(html)
  } catch (e) {
    next(e)
  }
})

app.get('/home', function (req, res, next) {
  try {
    var html = home({pageData: {chat_id : uuidv1()}})
    res.send(html)
  } catch (e) {
    next(e)
  }
})

app.use( bodyParser.json() );
app.use(bodyParser.urlencoded({
  extended: true
}));

function buildCommand(employee_id, response, timestamp) {
  return Promise.resolve(getEmpInfo(employee_id)).then(function(emp) {
    var scriptPath = __dirname + "/source/resources/";
    var options = {
      mode: 'text',
      pythonPath: '/usr/local/bin/python3',
      pythonOptions: ['-u'],
      scriptPath: scriptPath,
      args: [stringToNumeral("other"), employee_id, stringToNumeral("chat"), stringToNumeral(emp.UH_ORG_SEGMENT), stringToNumeral(emp.UH_ORG_BUSINESS), stringToNumeral(stripLocation(emp.LOCATION_CD)), stringToNumeral(emp.USER_TYPE), timestamp]
    };
    return options;
  });
}

function stripLocation(keyword) {
  var temp;
  if(keyword.toString().includes("int") || keyword.toString().includes("INT")) {
    temp = keyword.toString().substring(0, 3);
  }
  temp = keyword.toString().substring(0, 2);

  return temp;
}

function stringToNumeral(key) {
  return jsonObject[key.toLowerCase()];
}

function plz(err, results){
  if (err) throw err;
  return results;
}

function runPython(options, req) {

  var pyshell = new PythonShell('classifier.py', options);

  Promise.resolve(pyshell.on('message', function (message) {
    console.log(message);
    return message;
  })).then((output) => {
    console.log("Results2 >> " + output);
    var probability = output.toString().split("#");
    var botResponse = "Here is what I was able to find:\n" +
            "There is a " + probability[1] + " probability that the ticket should be routed to " + probability[0] + "\n" +
            "Did this solve your issue? (Reply with Yes or No)";
    var botLog = new Chatlog(req.params.id, 0000, botResponse);
    mongoInsert(botLog);
  });
}

function sendHtml(req, res) {
  console.log("2nd");
  mongoSearch(req.params.id).then(function(logs) {
    Promise.resolve(searchEmployee(req.body.employee_id)).then(function(name) {
      var html = chat({pageData: {employee_name : name,
                                  employee_id : req.body.employee_id,
                                  chat_id : req.params.id,
                                  logs: logs
                                }});
      res.send(html);
    });
  });
}

app.post('/chats/:id', function (req, res) {
  if(req.body.response != null) {
    var log = new Chatlog(req.params.id, req.body.employee_id, req.body.response);
    mongoInsert(log);

    buildCommand(req.body.employee_id, req.body.response, (new Date()).getMilliseconds())
    .then((options) => {
      return runPython(options, req);
    })
    .then((output) => {
      return sendHtml(req, res);
    });
  } else {
      mongoSearch(req.params.id).then((logs) => {
        Promise.resolve(searchEmployee(req.body.employee_id)).then(function(name) {
          var html = chat({pageData: {employee_name : name,
                                    employee_id : req.body.employee_id,
                                    chat_id : req.params.id,
                                    logs: logs
                                  }});
          res.send(html);
        });
      });
    }
})

app.get('/chats/:id', function (req, res) {
  mongoSearch(req.params.id).then(function(logs) {
    var employee_id = logs[0].employee_id;
    Promise.resolve(searchEmployee(employee_id)).then(function(name) {
      var html = chat({pageData: {employee_name : name,
                                  employee_id : employee_id,
                                  chat_id : req.params.id,
                                  logs: logs
                                }});
      res.send(html);
    });
  });
})

function searchEmployee(employee_id) {
  return client.search({
    index: 'twiggy_api_01',
    type: 'worker',
    body: {
      query: {
        match: {
          'UH_CALLBACK_CONTACT': employee_id
        }
      }
    }
  }).then(function (resp) {
      var hits = resp.hits.hits;
      return hits[0]._source.CALLER;
  }, function (err) {
      console.trace(err.message);
  });
}

function Chatlog(chat_id, employee_id, response) {
    this.chat_id = chat_id;
    this.employee_id = employee_id;
    this.response = response;
    var timedate = new Date();
    var hours = timedate.getHours();
    this.timestamp = (timedate.getMonth()+1) + "/" + timedate.getDate() + "/" + timedate.getFullYear() + " " + ((hours > 12) ? (hours - 12) : hours) + ":" + timedate.getMinutes() + ":" + timedate.getSeconds() + " " + ((hours > 12) ? "PM" : "AM");
}

Chatlog.prototype = {
    constructor: Chatlog
    , getChatId: function() {
        return this.chat_id
    }
    , getEmployeeId: function() {
        return this.employee_id
    }
    , getResponse: function()  {
        return this.response
    }
    , getTimestamp: function()  {
        return this.timestamp
    }
}

function getEmpInfo(employee_id) {
  return client.search({
    index: 'twiggy_api_01',
    type: 'worker',
    body: {
      query: {
        match: {
          'UH_CALLBACK_CONTACT': employee_id
        }
      }
    }
  }).then(function (resp) {
      var hits = resp.hits.hits;
      return hits[0]._source;
  }, function (err) {
      console.trace(err.message);
  });
}

function Employee(caller, uhCallbackContact, uhOrgSegment, uhOrgBusiness, uhOrgDivision, uhGlCode, locationCd, userType, title) {
  this.caller = caller;
  this.uhCallbackContact = uhCallbackContact;
  this.uhOrgSegment = uhOrgSegment;
  this.uhOrgBusiness = uhOrgBusiness;
  this.uhOrgDivision = uhOrgDivision;
  this.uhGlCode = uhGlCode;
  this.locationCd = locationCd;
  this.userType = userType;
  this.title = title;
}

Employee.prototype = {
    constructor: Employee
    , getUhCallbackContact: function() {
        return this.uhCallbackContact
    }
    , getCaller: function() {
        return this.caller
    }
    , getUhOrgSegment: function() {
        return this.uhOrgSegment
    }
    , getUhOrgBusiness: function()  {
        return this.uhOrgBusiness
    }
    , getUhOrgDivision: function()  {
        return this.uhOrgDivision
    }
    , getUhGlCode: function()  {
        return this.uhGlCode
    }
    , getLocationCd: function()  {
        return this.locationCd
    }
    , getUserType: function()  {
        return this.userType
    }
    , getTitle: function()  {
        return this.title
    }
}

app.listen(8080, function () {
  console.log('Listening on http://localhost:8080')
})
